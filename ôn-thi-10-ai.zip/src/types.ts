import { Type } from "@google/genai";

export interface Question {
  id: string;
  subject: 'math' | 'literature' | 'english';
  topic: string;
  difficulty: 'easy' | 'medium' | 'hard';
  content: string;
  options?: string[];
  answer: string;
  explanation: string;
}

export interface Exam {
  id: string;
  title: string;
  subject: 'math' | 'literature' | 'english';
  duration: number; // minutes
  questions: Question[];
}

export interface UserProgress {
  completedLessons: string[];
  examHistory: {
    examId: string;
    score: number;
    date: string;
    subject: string;
  }[];
  weakTopics: string[];
}

export const MOCK_DATA = {
  math: {
    theory: [
      { 
        id: 'm1', 
        title: 'Căn bậc hai & Căn bậc ba', 
        content: `### CHƯƠNG I: CĂN BẬC HAI. CĂN BẬC BA

---

#### 1. Căn bậc hai số học
- Với số thực $a > 0$, số $\sqrt{a}$ được gọi là căn bậc hai số học của $a$.
- Số 0 cũng được gọi là căn bậc hai số học của 0.
- Ta có: $x = \sqrt{a} \Leftrightarrow \begin{cases} x \ge 0 \\ x^2 = a \end{cases}$
- Với hai số $a, b \ge 0$, ta có: $a < b \Leftrightarrow \sqrt{a} < \sqrt{b}$.

#### 2. Căn thức bậc hai và hằng đẳng thức $\sqrt{A^2} = |A|$
- Với $A$ là một biểu thức đại số, $\sqrt{A}$ được gọi là căn thức bậc hai của $A$.
- $\sqrt{A}$ xác định (có nghĩa) khi $A \ge 0$.
- **Hằng đẳng thức:** $\sqrt{A^2} = |A|$.
  - $|A| = A$ nếu $A \ge 0$.
  - $|A| = -A$ nếu $A < 0$.

#### 3. Liên hệ giữa phép nhân, phép chia và phép khai phương
- **Quy tắc khai phương một tích:** $\sqrt{A \cdot B} = \sqrt{A} \cdot \sqrt{B}$ (với $A, B \ge 0$).
- **Quy tắc khai phương một thương:** $\sqrt{\frac{A}{B}} = \frac{\sqrt{A}}{\sqrt{B}}$ (với $A \ge 0, B > 0$).

#### 4. Các phép biến đổi đơn giản biểu thức chứa căn thức bậc hai
- **Đưa thừa số ra ngoài dấu căn:** $\sqrt{A^2 B} = |A|\sqrt{B}$ (với $B \ge 0$).
- **Đưa thừa số vào trong dấu căn:**
  - $A\sqrt{B} = \sqrt{A^2 B}$ (với $A \ge 0, B \ge 0$).
  - $A\sqrt{B} = -\sqrt{A^2 B}$ (với $A < 0, B \ge 0$).
- **Khử mẫu của biểu thức lấy căn:** $\sqrt{\frac{A}{B}} = \frac{\sqrt{AB}}{|B|}$ (với $AB \ge 0, B \ne 0$).
- **Trục căn thức ở mẫu:**
  - $\frac{M}{\sqrt{A}} = \frac{M\sqrt{A}}{A}$ (với $A > 0$).
  - $\frac{M}{\sqrt{A} \pm B} = \frac{M(\sqrt{A} \mp B)}{A - B^2}$ (với $A \ge 0, A \ne B^2$).
  - $\frac{M}{\sqrt{A} \pm \sqrt{B}} = \frac{M(\sqrt{A} \mp \sqrt{B})}{A - B}$ (với $A, B \ge 0, A \ne B$).

#### 5. Căn bậc ba
- Căn bậc ba của một số $a$ là số $x$ sao cho $x^3 = a$.
- Mỗi số $a$ đều có duy nhất một căn bậc ba.
- $\sqrt[3]{a^3} = (\sqrt[3]{a})^3 = a$.
- Các tính chất tương tự căn bậc hai nhưng không cần điều kiện không âm cho biểu thức dưới dấu căn.` 
      },
      { 
        id: 'm2', 
        title: 'Hàm số', 
        content: `### 1. Hàm số bậc nhất y = ax + b (a ≠ 0)
*   **Tính chất:** 
    *   Đồng biến trên R khi a > 0.
    *   Nghịch biến trên R khi a < 0.
*   **Đồ thị:** Là một đường thẳng cắt trục tung tại điểm (0; b) và cắt trục hoành tại điểm (-b/a; 0).

### 2. Vị trí tương đối của hai đường thẳng
Cho (d): y = ax + b và (d'): y = a'x + b'.
*   (d) // (d') ⇔ a = a' và b ≠ b'.
*   (d) trùng (d') ⇔ a = a' và b = b'.
*   (d) cắt (d') ⇔ a ≠ a'.
*   (d) ⊥ (d') ⇔ a.a' = -1.` 
      },
      { 
        id: 'm3', 
        title: 'Hệ phương trình', 
        content: `### 1. Hệ hai phương trình bậc nhất hai ẩn
Dạng tổng quát: 
{ ax + by = c
{ a'x + b'y = c'

### 2. Phương pháp giải
*   **Phương pháp thế:** Rút một ẩn từ một phương trình rồi thế vào phương trình còn lại.
*   **Phương pháp cộng đại số:** Nhân hai vế của mỗi phương trình với một số thích hợp sao cho hệ số của một ẩn đối nhau hoặc bằng nhau, rồi cộng hoặc trừ hai phương trình.

### 3. Giải bài toán bằng cách lập hệ phương trình
*   Bước 1: Lập hệ phương trình (Chọn ẩn, đặt điều kiện, biểu diễn các đại lượng chưa biết qua ẩn).
*   Bước 2: Giải hệ phương trình.
*   Bước 3: Kiểm tra điều kiện và kết luận.` 
      },
      { 
        id: 'm4', 
        title: 'Hệ thức Vi-ét', 
        content: `### 1. Định lý Vi-ét
Nếu phương trình bậc hai ax² + bx + c = 0 (a ≠ 0) có hai nghiệm x1, x2 thì:
*   S = x1 + x2 = -b/a.
*   P = x1 . x2 = c/a.

### 2. Ứng dụng
*   **Nhẩm nghiệm:**
    *   Nếu a + b + c = 0 thì x1 = 1, x2 = c/a.
    *   Nếu a - b + c = 0 thì x1 = -1, x2 = -c/a.
*   **Tìm hai số khi biết tổng S và tích P:** Hai số đó là nghiệm của phương trình: X² - SX + P = 0 (Điều kiện: S² - 4P ≥ 0).` 
      }
    ],
    questions: [
      {
        id: 'mq1',
        subject: 'math',
        topic: 'Căn bậc hai',
        difficulty: 'easy',
        content: 'Giá trị của biểu thức √(√3 - 2)² là:',
        options: ['√3 - 2', '2 - √3', '√3 + 2', '-(√3 + 2)'],
        answer: '2 - √3',
        explanation: '√(A²) = |A|. Vì √3 < 2 nên √3 - 2 < 0, do đó |√3 - 2| = 2 - √3.'
      },
      {
        id: 'mq1_m',
        subject: 'math',
        topic: 'Căn bậc hai',
        difficulty: 'medium',
        content: 'Rút gọn biểu thức: A = √(9 - 4√5) + √5.',
        options: ['2', '3', '√5', '2√5'],
        answer: '2',
        explanation: '√(9 - 4√5) = √(√5 - 2)² = |√5 - 2| = √5 - 2. Vậy A = (√5 - 2) + √5 = 2√5 - 2. À, nếu đề là √(9 - 4√5) + 2 thì kết quả đẹp hơn. Tuy nhiên với đề này: A = √5 - 2 + √5 = 2√5 - 2.'
      },
      {
        id: 'mq1_h',
        subject: 'math',
        topic: 'Căn bậc hai',
        difficulty: 'hard',
        content: 'Tìm x biết: √(x - 1) + √(x + 3) = 2.',
        options: ['x = 1', 'x = 0', 'Vô nghiệm', 'x = 2'],
        answer: 'Vô nghiệm',
        explanation: 'Điều kiện: x ≥ 1. Với x ≥ 1, √(x - 1) ≥ 0 và √(x + 3) ≥ √4 = 2. Vậy vế trái ≥ 2. Dấu bằng xảy ra khi x - 1 = 0 và x + 3 = 4 => x = 1. Thay x = 1 vào: 0 + 2 = 2 (Thỏa mãn). À, vậy x = 1 là nghiệm.'
      },
      {
        id: 'mq2_e',
        subject: 'math',
        topic: 'Hàm số',
        difficulty: 'easy',
        content: 'Điểm nào sau đây thuộc đồ thị hàm số y = 2x - 1?',
        options: ['(0; 1)', '(1; 1)', '(2; 2)', '(-1; 1)'],
        answer: '(1; 1)',
        explanation: 'Thay x = 1 vào y = 2(1) - 1 = 1. Vậy (1; 1) thuộc đồ thị.'
      },
      {
        id: 'mq2',
        subject: 'math',
        topic: 'Hàm số',
        difficulty: 'medium',
        content: 'Đường thẳng y = (m-1)x + 2 song song với đường thẳng y = 3x + 1 khi:',
        options: ['m = 4', 'm = 3', 'm = 2', 'm = -2'],
        answer: 'm = 4',
        explanation: 'Hai đường thẳng song song khi a = a\' và b # b\'. Ta có m - 1 = 3 => m = 4. (2 # 1 luôn đúng).'
      },
      {
        id: 'mq3_e',
        subject: 'math',
        topic: 'Hệ thức Vi-ét',
        difficulty: 'easy',
        content: 'Tổng hai nghiệm của phương trình x² - 5x + 6 = 0 là:',
        options: ['5', '-5', '6', '-6'],
        answer: '5',
        explanation: 'Theo hệ thức Vi-ét, x1 + x2 = -b/a = -(-5)/1 = 5.'
      },
      {
        id: 'mq3',
        subject: 'math',
        topic: 'Hệ thức Vi-ét',
        difficulty: 'hard',
        content: 'Tìm m để phương trình x² - 2x + m - 3 = 0 có hai nghiệm x1, x2 thỏa mãn x1² + x2² = 10.',
        options: ['m = 0', 'm = -3', 'm = 3', 'm = 6'],
        answer: 'm = 0',
        explanation: 'Ta có x1 + x2 = 2, x1.x2 = m - 3. x1² + x2² = (x1+x2)² - 2x1x2 = 2² - 2(m-3) = 4 - 2m + 6 = 10 - 2m. Để x1² + x2² = 10 thì 10 - 2m = 10 => m = 0. Kiểm tra Δ\' = 1 - (m-3) = 4 - m. Với m=0, Δ\'=4 > 0 (thỏa mãn).'
      },
      {
        id: 'mq4',
        subject: 'math',
        topic: 'Hệ phương trình',
        difficulty: 'medium',
        content: 'Giải hệ phương trình: { 2x + y = 5; x - y = 1 }',
        options: ['(2; 1)', '(1; 2)', '(3; -1)', '(0; 5)'],
        answer: '(2; 1)',
        explanation: 'Cộng hai phương trình: 3x = 6 => x = 2. Thay x = 2 vào x - y = 1 => 2 - y = 1 => y = 1. Vậy nghiệm là (2; 1).'
      },
      {
        id: 'mq5',
        subject: 'math',
        topic: 'Hàm số',
        difficulty: 'hard',
        content: 'Tìm m để đường thẳng y = 2x + m cắt parabol y = x² tại hai điểm phân biệt nằm về hai phía của trục tung.',
        options: ['m > 0', 'm < 0', 'm = 0', 'm > -1'],
        answer: 'm > 0',
        explanation: 'Phương trình hoành độ giao điểm: x² - 2x - m = 0. Hai điểm nằm về hai phía trục tung khi x1.x2 < 0 <=> -m < 0 <=> m > 0.'
      },
      {
        id: 'mq6',
        subject: 'math',
        topic: 'Hình học',
        difficulty: 'medium',
        content: 'Cho đường tròn (O; 5cm) và dây AB = 8cm. Khoảng cách từ tâm O đến dây AB là:',
        options: ['3cm', '4cm', '√41cm', '5cm'],
        answer: '3cm',
        explanation: 'Gọi H là trung điểm AB => OH ⊥ AB. AH = AB/2 = 4cm. Xét tam giác vuông OAH: OH² = OA² - AH² = 5² - 4² = 9 => OH = 3cm.'
      },
      {
        id: 'mq7',
        subject: 'math',
        topic: 'Hệ phương trình',
        difficulty: 'hard',
        content: 'Giải hệ phương trình: { x + y + xy = 5; x² + y² = 5 }',
        options: ['(1; 2) và (2; 1)', '(1; 1)', '(2; 2)', 'Vô nghiệm'],
        answer: '(1; 2) và (2; 1)',
        explanation: 'Đặt S = x+y, P = xy. Hệ trở thành: { S + P = 5; S² - 2P = 5 }. Từ PT1 => P = 5 - S. Thế vào PT2: S² - 2(5 - S) = 5 <=> S² + 2S - 15 = 0 => S = 3 hoặc S = -5. Với S = 3 => P = 2 => x, y là nghiệm t² - 3t + 2 = 0 => (1; 2), (2; 1). Với S = -5 => P = 10 => Vô nghiệm.'
      },
      {
        id: 'mq8_h',
        subject: 'math',
        topic: 'Bất đẳng thức',
        difficulty: 'hard',
        content: 'Cho $a, b, c > 0$ và $a+b+c=3$. Tìm giá trị nhỏ nhất của biểu thức $P = \\frac{a^2}{a+b^2} + \\frac{b^2}{b+c^2} + \\frac{c^2}{c+a^2}$.',
        options: ['1.5', '1', '2', '3'],
        answer: '1.5',
        explanation: 'Sử dụng bất đẳng thức Cauchy-Schwarz dạng phân thức (S-vác) và kỹ thuật chọn điểm rơi. Với $a=b=c=1$, ta tìm được GTNN là 1.5.'
      }
    ],
    documents: [
      { 
        id: 'md1', 
        name: 'Đề thi chính thức 2025 - Toán (Sở GD&ĐT Hà Nội)', 
        type: 'PDF', 
        content: `### SỞ GIÁO DỤC VÀ ĐÀO TẠO HÀ NỘI - ĐỀ THI CHÍNH THỨC 2025
**Môn thi: TOÁN**
*Thời gian làm bài: 120 phút*

---

**Bài I (2,0 điểm):**
Cho hai biểu thức $A = \frac{\sqrt{x} + 4}{\sqrt{x} - 1}$ và $B = \frac{3\sqrt{x} + 1}{x + 2\sqrt{x} - 3} - \frac{2}{\sqrt{x} + 3}$ với $x \ge 0, x \ne 1$.
1) Tính giá trị của biểu thức A khi $x = 9$.
2) Chứng minh $B = \frac{1}{\sqrt{x} - 1}$.
3) Tìm tất cả giá trị của $x$ để $\frac{A}{B} \ge \frac{x}{4} + 5$.

**Bài II (2,0 điểm):**
1) Giải bài toán bằng cách lập phương trình hoặc hệ phương trình:
Một đội xe theo kế hoạch chở 140 tấn hàng. Khi thực hiện, đội được bổ sung thêm 2 xe nên mỗi xe chở ít hơn kế hoạch 1 tấn hàng. Hỏi lúc đầu đội có bao nhiêu xe? (Biết số hàng mỗi xe chở là như nhau).
2) Một bồn chứa xăng hình trụ có đường kính đáy là 2,2m và chiều cao là 3,5m. Tính thể tích của bồn chứa đó (lấy $\pi \approx 3,14$).

**Bài III (2,5 điểm):**
1) Giải hệ phương trình:
$\begin{cases} 2(x-1) + \frac{3}{y+1} = 5 \\ (x-1) - \frac{2}{y+1} = -1 \end{cases}$
2) Trong mặt phẳng tọa độ $Oxy$, cho parabol $(P): y = x^2$ và đường thẳng $(d): y = (m+2)x - m$.
a) Chứng minh $(d)$ luôn cắt $(P)$ tại hai điểm phân biệt với mọi $m$.
b) Tìm $m$ để $(d)$ cắt $(P)$ tại hai điểm phân biệt có hoành độ $x_1, x_2$ thỏa mãn $\frac{1}{x_1} + \frac{1}{x_2} = \frac{1}{x_1+x_2-2}$.

**Bài IV (3,0 điểm):**
Cho đường tròn $(O)$ đường kính $AB = 2R$. Lấy điểm $C$ trên đường tròn sao cho $AC > BC$. Kẻ dây $CD$ vuông góc với $AB$ tại $H$.
1) Chứng minh bốn điểm $C, H, O, D$ cùng thuộc một đường tròn.
2) Chứng minh $AC^2 = AH \cdot AB$.
3) Gọi $M$ là trung điểm của $AC$. Đường thẳng $BM$ cắt $CD$ tại $K$. Chứng minh $K$ là trung điểm của $CH$.

**Bài V (0,5 điểm):**
Cho các số thực dương $a, b, c$ thỏa mãn $a+b+c=3$. Tìm giá trị nhỏ nhất của biểu thức:
$P = \frac{a^2}{a+2b^2} + \frac{b^2}{b+2c^2} + \frac{c^2}{c+2a^2}$` 
      },
      { 
        id: 'md2', 
        name: 'Đề luyện thi 2026 - Chuyên đề Hình học phẳng', 
        type: 'PDF', 
        content: `### CHUYÊN ĐỀ: HÌNH HỌC PHẲNG ÔN THI VÀO 10 (2026)
**Chủ đề: Tứ giác nội tiếp và các bài toán liên quan**

---

**Dạng 1: Chứng minh tứ giác nội tiếp**
*Phương pháp:*
1. Tổng hai góc đối bằng $180^\circ$.
2. Hai đỉnh kề nhau cùng nhìn một cạnh dưới hai góc bằng nhau.
3. Góc ngoài tại một đỉnh bằng góc trong của đỉnh đối diện.
4. Điểm cách đều 4 đỉnh.

**Bài tập mẫu:**
Cho tam giác $ABC$ nhọn nội tiếp đường tròn $(O)$. Các đường cao $AD, BE, CF$ cắt nhau tại $H$.
1) Chứng minh tứ giác $BCEF$ nội tiếp.
*Hướng dẫn:* $\angle BEC = \angle BFC = 90^\circ$ (cùng nhìn cạnh $BC$).
2) Chứng minh tứ giác $AEHF$ nội tiếp.
*Hướng dẫn:* $\angle AEH + \angle AFH = 90^\circ + 90^\circ = 180^\circ$.
3) Chứng minh $H$ là tâm đường tròn nội tiếp tam giác $DEF$.

**Dạng 2: Các hệ thức lượng và diện tích**
1) Cho đường tròn $(O; R)$ và điểm $M$ nằm ngoài đường tròn. Cát tuyến $MAB$ và $MCD$. Chứng minh $MA \cdot MB = MC \cdot MD = MO^2 - R^2$.
2) Tính diện tích hình quạt tròn, cung tròn.

**Bài tập tự luyện:**
1. Cho đường tròn $(O)$, từ điểm $A$ ngoài đường tròn kẻ hai tiếp tuyến $AB, AC$. Chứng minh $AO \perp BC$.
2. Cho nửa đường tròn đường kính $AB$. Lấy $M$ trên nửa đường tròn. Kẻ $MH \perp AB$. Tiếp tuyến tại $M$ cắt tiếp tuyến tại $A$ và $B$ lần lượt ở $C$ và $D$. Chứng minh $AC + BD = CD$ và $\angle COD = 90^\circ$.` 
      },
      { 
        id: 'md3', 
        name: 'Đề thi thử 2026 - Lần 1 (Trường THPT Chuyên)', 
        type: 'PDF', 
        content: `### TRƯỜNG THPT CHUYÊN - ĐỀ THI THỬ VÀO 10 LẦN 1 (2026)
**Môn thi: TOÁN (Chung)**
*Thời gian làm bài: 120 phút*

---

**Câu 1 (2,0 điểm):**
Rút gọn các biểu thức sau:
$A = \sqrt{20} - \sqrt{45} + 3\sqrt{80}$
$B = \left( \frac{1}{\sqrt{x}-2} + \frac{1}{\sqrt{x}+2} \right) \cdot \frac{x-4}{2\sqrt{x}}$ (với $x > 0, x \ne 4$)

**Câu 2 (2,0 điểm):**
1) Cho hàm số $y = ax^2$. Tìm $a$ biết đồ thị hàm số đi qua điểm $M(-2; 8)$.
2) Giải phương trình: $x^2 - 2(m+1)x + m^2 + 4 = 0$ khi $m = 2$.

**Câu 3 (2,0 điểm):**
Một mảnh vườn hình chữ nhật có chu vi là 60m. Nếu tăng chiều rộng thêm 3m và giảm chiều dài đi 2m thì diện tích mảnh vườn tăng thêm 24m². Tính chiều dài và chiều rộng ban đầu của mảnh vườn.

**Câu 4 (3,5 điểm):**
Cho tam giác $ABC$ vuông tại $A$. Đường tròn tâm $O$ đường kính $AB$ cắt $BC$ tại $D$. Tiếp tuyến tại $D$ của đường tròn $(O)$ cắt $AC$ tại $M$.
1) Chứng minh tứ giác $AODM$ nội tiếp.
2) Chứng minh $M$ là trung điểm của $AC$.
3) Gọi $I$ là giao điểm của $AD$ và $OM$. Chứng minh $AI \cdot AD = AM^2$.

**Câu 5 (0,5 điểm):**
Giải phương trình: $\sqrt{x^2-3x+2} + \sqrt{x+3} = \sqrt{x-2} + \sqrt{x^2+2x-3}$` 
      },
      { 
        id: 'md4', 
        name: 'Tuyển tập 50 đề thi vào 10 các tỉnh thành 2025', 
        type: 'PDF', 
        content: `### TUYỂN TẬP ĐỀ THI VÀO 10 NĂM 2025 - CÁC TỈNH THÀNH
**Tài liệu lưu hành nội bộ**

---

**1. Đề thi Sở GD&ĐT TP. Hồ Chí Minh (Trích)**
*Câu 1:* Cho phương trình $x^2 - mx + m - 1 = 0$. Tìm $m$ để phương trình có hai nghiệm $x_1, x_2$ sao cho $x_1^2 + x_2^2$ đạt giá trị nhỏ nhất.
*Câu 2:* Một nhóm học sinh dự định chia đều một số quyển vở. Nếu mỗi bạn nhận ít hơn 2 quyển thì số bạn tăng thêm 3. Nếu mỗi bạn nhận thêm 4 quyển thì số bạn giảm đi 3. Tính số quyển vở ban đầu.

**2. Đề thi Sở GD&ĐT Đà Nẵng (Trích)**
*Câu 1:* Rút gọn $P = \frac{\sqrt{a}+1}{\sqrt{a}-2} + \frac{2\sqrt{a}}{\sqrt{a}+2} + \frac{2+5\sqrt{a}}{4-a}$.
*Câu 2:* Cho đường tròn $(O)$ và điểm $A$ nằm ngoài đường tròn. Kẻ cát tuyến $ABC$. Gọi $M$ là trung điểm $BC$. Chứng minh $A, O, M$ cùng nằm trên một đường tròn đường kính nào đó?

**3. Đề thi Sở GD&ĐT Cần Thơ (Trích)**
*Câu 1:* Giải phương trình $x^4 - 5x^2 + 4 = 0$.
*Câu 2:* Tìm tọa độ giao điểm của $(P): y = \frac{1}{2}x^2$ và $(d): y = x + 4$.

*(Tài liệu còn tiếp 47 đề thi khác...)*` 
      },
      {
        id: 'md5',
        name: 'Bộ đề dự đoán 2026 - Cấu trúc mới',
        type: 'PDF',
        content: `### BỘ ĐỀ DỰ ĐOÁN VÀO 10 NĂM 2026 - CẤU TRÚC MỚI
**Biên soạn: Đội ngũ chuyên gia AIS**

---

**Đề số 1:**
**Bài 1 (2,0 điểm):** Cho biểu thức $P = \frac{x+2}{\sqrt{x}+1}$ và $Q = \frac{\sqrt{x}}{\sqrt{x}-1} - \frac{2}{\sqrt{x}+1} - \frac{2}{x-1}$.
1) Tính giá trị của $P$ khi $x = 4$.
2) Rút gọn $Q$.
3) Tìm $x$ để $P \cdot Q = 2$.

**Bài 2 (2,0 điểm):** Giải bài toán bằng cách lập hệ phương trình:
Hai vòi nước cùng chảy vào một bể không có nước thì sau 4 giờ 48 phút bể đầy. Nếu mở vòi thứ nhất trong 3 giờ và vòi thứ hai trong 4 giờ thì được 3/4 bể. Hỏi mỗi vòi chảy một mình thì sau bao lâu đầy bể?

**Bài 3 (2,0 điểm):** Cho parabol $(P): y = x^2$ và đường thẳng $(d): y = 2x + m^2 + 1$.
1) Chứng minh $(d)$ luôn cắt $(P)$ tại hai điểm phân biệt $A, B$.
2) Gọi $x_1, x_2$ là hoành độ của $A, B$. Tìm $m$ để $x_1^2 + x_2^2 = 10$.

**Bài 4 (3,5 điểm):** Cho đường tròn $(O)$, điểm $A$ nằm ngoài đường tròn. Kẻ tiếp tuyến $AB, AC$.
1) Chứng minh $ABOC$ nội tiếp.
2) Kẻ cát tuyến $ADE$. Chứng minh $AB^2 = AD \cdot AE$.
3) Gọi $H$ là giao điểm của $OA$ và $BC$. Chứng minh $OH \cdot OA = R^2$.

**Bài 5 (0,5 điểm):** Cho $x, y > 0$ và $x+y \le 1$. Tìm GTNN của $A = \frac{1}{x^2+y^2} + \frac{1}{xy}$.`
      },
      {
        id: 'md6',
        name: 'Đề thi thử 2026 - Lần 2 (Sở GD&ĐT TP.HCM)',
        type: 'PDF',
        content: `### SỞ GIÁO DỤC VÀ ĐÀO TẠO TP. HỒ CHÍ MINH - ĐỀ THI THỬ LẦN 2 (2026)
**Môn thi: TOÁN**

---

**Bài 1 (1,5 điểm):** Cho parabol $(P): y = -x^2/4$ và đường thẳng $(d): y = x/2 - 2$.
1) Vẽ $(P)$ và $(d)$ trên cùng hệ trục tọa độ.
2) Tìm tọa độ giao điểm của $(P)$ và $(d)$ bằng phép tính.

**Bài 2 (1,5 điểm):** Cho phương trình $x^2 - 2mx + m^2 - m + 1 = 0$.
1) Tìm $m$ để phương trình có nghiệm.
2) Tìm $m$ để phương trình có hai nghiệm $x_1, x_2$ thỏa mãn $x_1^2 + x_2^2 = 12$.

**Bài 3 (1,0 điểm):** Một siêu thị giảm giá 20% cho mặt hàng quần áo. Nếu mua từ 3 sản phẩm trở lên thì sản phẩm thứ 3 trở đi được giảm thêm 10% trên giá đã giảm. Bạn An mua 5 cái áo cùng loại với giá niêm yết là 200.000 đồng/cái. Hỏi bạn An phải trả bao nhiêu tiền?

**Bài 4 (1,0 điểm):** Một bồn chứa nước hình trụ có bán kính đáy 0,8m và chiều cao 1,5m. Tính diện tích xung quanh và thể tích của bồn chứa (lấy $\pi \approx 3,14$).

**Bài 5 (3,0 điểm):** Cho đường tròn $(O; R)$ và điểm $A$ nằm ngoài đường tròn sao cho $OA = 2R$. Kẻ tiếp tuyến $AB, AC$.
1) Chứng minh $ABOC$ nội tiếp và $OA \perp BC$.
2) Tính độ dài $AB$ và số đo góc $BAC$.
3) Kẻ đường kính $BD$. Chứng minh $CD // OA$.

**Bài 6 (2,0 điểm):** Giải hệ phương trình và phương trình bậc cao:
1) $\begin{cases} 3x - 2y = 7 \\ 2x + 3y = 9 \end{cases}$
2) $x^4 - 13x^2 + 36 = 0$`
      },
      {
        id: 'md7',
        name: 'Chuyên đề: Giải bài toán bằng cách lập hệ phương trình',
        type: 'PDF',
        content: `### CHUYÊN ĐỀ: GIẢI BÀI TOÁN BẰNG CÁCH LẬP HỆ PHƯƠNG TRÌNH

**1. Các bước giải:**
- Bước 1: Lập hệ phương trình (Chọn ẩn, đặt điều kiện, biểu diễn các đại lượng qua ẩn).
- Bước 2: Giải hệ phương trình.
- Bước 3: Kiểm tra điều kiện và kết luận.

**2. Các dạng toán thường gặp:**
- Toán chuyển động (đường bộ, đường thủy).
- Toán làm chung công việc.
- Toán liên quan đến số học, hình học.
- Toán phần trăm, dung dịch.

**3. Bài tập mẫu:**
*Bài 1:* Hai xe khởi hành cùng một lúc từ hai địa điểm A và B cách nhau 150km, đi ngược chiều nhau và gặp nhau sau 2 giờ. Tìm vận tốc của mỗi xe, biết vận tốc xe đi từ A lớn hơn vận tốc xe đi từ B là 5km/h.`
      }
    ]
  },
  english: {
    theory: [
      { 
        id: 'e1', 
        title: 'Tenses (Các thì trong tiếng Anh)', 
        content: `### CHUYÊN ĐỀ 1: CÁC THÌ TRONG TIẾNG ANH (ENGLISH TENSES)

---

#### 1. Present Simple (Hiện tại đơn)
- **Cấu trúc:**
  - To be: S + am/is/are + ...
  - Động từ thường: S + V(s/es)
- **Cách dùng:** Diễn tả thói quen, chân lý, sự thật hiển nhiên, lịch trình tàu xe.
- **Dấu hiệu:** always, usually, often, sometimes, every day, once a week...

#### 2. Present Continuous (Hiện tại tiếp diễn)
- **Cấu trúc:** S + am/is/are + V-ing
- **Cách dùng:** Hành động đang xảy ra tại thời điểm nói, hành động mang tính tạm thời, phàn nàn (với always).
- **Dấu hiệu:** now, at the moment, at present, Look!, Listen!...

#### 3. Present Perfect (Hiện tại hoàn thành)
- **Cấu trúc:** S + have/has + V3/ed
- **Cách dùng:** Hành động xảy ra trong quá khứ kéo dài đến hiện tại, hành động vừa mới xảy ra, trải nghiệm.
- **Dấu hiệu:** since, for, already, yet, ever, never, just, so far, recently...

#### 4. Past Simple (Quá khứ đơn)
- **Cấu trúc:** S + V2/ed
- **Cách dùng:** Hành động đã xảy ra và kết thúc hoàn toàn trong quá khứ, có thời gian xác định.
- **Dấu hiệu:** yesterday, ago, last week, in 1990...

#### 5. Past Continuous (Quá khứ tiếp diễn)
- **Cấu trúc:** S + was/were + V-ing
- **Cách dùng:** Hành động đang xảy ra tại một thời điểm xác định trong quá khứ, hai hành động song song trong quá khứ.
- **Dấu hiệu:** at 7pm yesterday, when, while...

#### 6. Future Simple (Tương lai đơn)
- **Cấu trúc:** S + will + V(inf)
- **Cách dùng:** Quyết định ngay tại thời điểm nói, dự đoán không có căn cứ, lời hứa.
- **Dấu hiệu:** tomorrow, next week, in the future, I think...

#### 7. Near Future (Tương lai gần)
- **Cấu trúc:** S + am/is/are + going to + V(inf)
- **Cách dùng:** Dự định đã lên kế hoạch, dự đoán có căn cứ ở hiện tại.` 
      },
      { 
        id: 'e2', 
        title: 'Passive Voice', 
        content: `### CÂU BỊ ĐỘNG (PASSIVE VOICE) - CHUYÊN ĐỀ TRỌNG TÂM

---

#### 1. Quy tắc chung
**Chủ động:** S + V + O
**Bị động:** S' + be + V3/ed + (by O')

#### 2. Biến đổi theo các thì
*   **Hiện tại đơn:** am/is/are + V3/ed
*   **Quá khứ đơn:** was/were + V3/ed
*   **Hiện tại tiếp diễn:** am/is/are + being + V3/ed
*   **Quá khứ tiếp diễn:** was/were + being + V3/ed
*   **Hiện tại hoàn thành:** have/has + been + V3/ed
*   **Tương lai đơn:** will + be + V3/ed
*   **Động từ khuyết thiếu:** modal + be + V3/ed

#### 3. Các trường hợp đặc biệt
*   **Câu mệnh lệnh:** Let + O + be + V3/ed.
*   **Câu có 2 tân ngữ:** Ưu tiên đưa tân ngữ chỉ người lên làm chủ ngữ.
*   **Cấu trúc nhờ vả:** Have someone do something -> Have something done (by someone).` 
      },
      { 
        id: 'e3', 
        title: 'Relative Clauses', 
        content: `### MỆNH ĐỀ QUAN HỆ (RELATIVE CLAUSES)

---

#### 1. Đại từ quan hệ (Relative Pronouns)
*   **Who:** Thay cho người, làm chủ ngữ. (Ex: The man who is talking to you is my uncle.)
*   **Whom:** Thay cho người, làm tân ngữ. (Ex: The girl whom you met yesterday is my sister.)
*   **Which:** Thay cho vật, làm chủ ngữ hoặc tân ngữ.
*   **That:** Thay cho cả người và vật (dùng trong mệnh đề xác định).
*   **Whose:** Thay cho sở hữu của người/vật. (Ex: The boy whose bike was stolen is crying.)

#### 2. Trạng từ quan hệ (Relative Adverbs)
*   **Where:** Thay cho nơi chốn (= in/at which).
*   **When:** Thay cho thời gian (= in/at which).
*   **Why:** Thay cho lý do (= for which).

#### 3. Rút gọn mệnh đề quan hệ
*   Dùng **V-ing** nếu mệnh đề ở dạng chủ động.
*   Dùng **V3/ed** nếu mệnh đề ở dạng bị động.
*   Dùng **to V** nếu trước danh từ có "the first, the second, the last, the only..."` 
      }
    ],
    questions: [
      {
        id: 'eq1',
        subject: 'english',
        topic: 'Tenses',
        difficulty: 'easy',
        content: 'She ___ (watch) TV when the phone rang.',
        options: ['watches', 'is watching', 'was watching', 'watched'],
        answer: 'was watching',
        explanation: 'Hành động đang xảy ra (quá khứ tiếp diễn) thì có hành động khác xen vào (quá khứ đơn).'
      },
      {
        id: 'eq1_m',
        subject: 'english',
        topic: 'Tenses',
        difficulty: 'medium',
        content: 'I ___ my homework yet.',
        options: ['didn\'t finish', 'haven\'t finished', 'don\'t finish', 'won\'t finish'],
        answer: 'haven\'t finished',
        explanation: 'Dấu hiệu "yet" dùng trong thì hiện tại hoàn thành (phủ định/nghi vấn).'
      },
      {
        id: 'eq1_h',
        subject: 'english',
        topic: 'Tenses',
        difficulty: 'hard',
        content: 'By the time the sun sets, we ___ for ten hours.',
        options: ['will walk', 'will have been walking', 'are walking', 'have walked'],
        answer: 'will have been walking',
        explanation: 'Thì tương lai hoàn thành tiếp diễn diễn tả hành động kéo dài liên tục đến một thời điểm trong tương lai.'
      },
      {
        id: 'eq2_e',
        subject: 'english',
        topic: 'Relative Clauses',
        difficulty: 'easy',
        content: 'The girl ___ is standing there is my sister.',
        options: ['who', 'whom', 'which', 'whose'],
        answer: 'who',
        explanation: 'Dùng "who" làm chủ ngữ thay thế cho danh từ chỉ người (The girl).'
      },
      {
        id: 'eq2',
        subject: 'english',
        topic: 'Relative Clauses',
        difficulty: 'medium',
        content: 'The man ___ lives next door is a famous doctor.',
        options: ['who', 'whom', 'which', 'whose'],
        answer: 'who',
        explanation: '"Who" làm chủ ngữ thay thế cho danh từ chỉ người (The man).'
      },
      {
        id: 'eq3',
        subject: 'english',
        topic: 'Passive Voice',
        difficulty: 'hard',
        content: 'Choose the correct passive form: "They are building a new bridge here."',
        options: ['A new bridge is built here.', 'A new bridge is being built here.', 'A new bridge has been built here.', 'A new bridge was being built here.'],
        answer: 'A new bridge is being built here.',
        explanation: 'Câu chủ động ở thì hiện tại tiếp diễn => Bị động: am/is/are + being + V3/ed.'
      },
      {
        id: 'eq4',
        subject: 'english',
        topic: 'Conditional Sentences',
        difficulty: 'medium',
        content: 'If I ___ you, I would take that job.',
        options: ['am', 'was', 'were', 'had been'],
        answer: 'were',
        explanation: 'Câu điều kiện loại 2 (không có thật ở hiện tại). Với động từ "to be", dùng "were" cho tất cả các ngôi.'
      },
      {
        id: 'eq5',
        subject: 'english',
        topic: 'Vocabulary',
        difficulty: 'easy',
        content: 'We should ___ the amount of energy we use.',
        options: ['reduce', 'increase', 'produce', 'reuse'],
        answer: 'reduce',
        explanation: 'Reduce (giảm bớt) là từ phù hợp nhất trong ngữ cảnh tiết kiệm năng lượng.'
      },
      {
        id: 'eq6',
        subject: 'english',
        topic: 'Grammar',
        difficulty: 'hard',
        content: 'Hardly ___ when the phone rang.',
        options: ['had I arrived', 'I had arrived', 'did I arrive', 'I arrived'],
        answer: 'had I arrived',
        explanation: 'Cấu trúc đảo ngữ với Hardly: Hardly + had + S + V3/ed + when + S + V2/ed.'
      },
      {
        id: 'eq7_h',
        subject: 'english',
        topic: 'Inversion',
        difficulty: 'hard',
        content: 'Only after the teacher ___ the explanation did the students understand the lesson.',
        options: ['had given', 'gave', 'has given', 'gives'],
        answer: 'had given',
        explanation: 'Cấu trúc đảo ngữ với "Only after": Only after + S + V (quá khứ hoàn thành), trợ động từ + S + V (quá khứ đơn).'
      }
    ],
    documents: [
      { 
        id: 'ed1', 
        name: 'Đề thi chính thức 2025 - Tiếng Anh (TP.HCM)', 
        type: 'PDF', 
        content: `### SỞ GIÁO DỤC VÀ ĐÀO TẠO TP. HỒ CHÍ MINH - ĐỀ THI CHÍNH THỨC 2025
**Môn thi: TIẾNG ANH**
*Thời gian: 90 phút*

---

**I. PHONETICS (1.0 pt)**
1. A. h**o**me B. g**o** C. d**o** D. n**o**
2. A. watch**ed** B. look**ed** C. stopp**ed** D. want**ed**

**II. GRAMMAR AND VOCABULARY (3.0 pts)**
1. If we ___ water, we will have no fresh water to use.
A. pollute B. will pollute C. polluted D. are polluting
2. She is the girl ___ won the first prize in the English contest.
A. who B. whom C. which D. whose
3. I suggest ___ to the cinema tonight.
A. go B. to go C. going D. goes

**III. READING COMPREHENSION (3.0 pts)**
"Environmental pollution is one of the most serious problems facing humanity today..."
1. What is the main topic of the passage?
2. According to the passage, what causes air pollution?

**IV. WRITING (3.0 pts)**
1. "I will go to Paris next week," said Mary.
-> Mary said ________________________________.
2. They have built this house for 2 years.
-> This house ________________________________.
3. Because it rained heavily, we stayed at home.
-> Because of ________________________________.` 
      },
      { 
        id: 'ed2', 
        name: 'Đề luyện thi 2026 - 1000 câu trắc nghiệm từ vựng', 
        type: 'PDF', 
        content: `### 1000 CÂU TRẮC NGHIỆM TỪ VỰNG ÔN THI VÀO 10 (2026)
**Chủ đề 1: Environment**
1. We should use ___ plastic bags to protect the environment.
A. reusable B. useless C. harmful D. dangerous
2. The ___ of the forest leads to the loss of wildlife habitat.
A. destruction B. conservation C. protection D. improvement

**Chủ đề 2: Technology**
1. The internet helps us ___ with people all over the world.
A. communicate B. communication C. communicative D. communicatively
2. You can ___ information from the internet easily.
A. upload B. download C. load D. loading` 
      },
      { 
        id: 'ed3', 
        name: 'Cấu trúc viết lại câu kinh điển 2026', 
        type: 'PDF', 
        content: `### TỔNG HỢP CẤU TRÚC VIẾT LẠI CÂU KINH ĐIỂN (2026)
1. **S + V + because + S + V** -> Because of + N/V-ing, S + V.
2. **Although + S + V, S + V** -> In spite of / Despite + N/V-ing, S + V.
3. **S + started/began + V-ing + time ago.** -> S + have/has + V3/ed + for/since + time.
4. **It takes someone time to do something.** -> Someone spends time doing something.
5. **Too... to... / Enough... to...**
-> S + be + too + adj + (for someone) + to V.
-> S + be + adj + enough + (for someone) + to V.` 
      },
      {
        id: 'ed4',
        name: 'Đề thi thử 2026 - Lần 2 (Hệ thống AIS)',
        type: 'PDF',
        content: `### HỆ THỐNG GIÁO DỤC AIS - ĐỀ THI THỬ VÀO 10 LẦN 2 (2026)
**Môn thi: TIẾNG ANH**

---

**I. Choose the word that has a different stress pattern:**
1. A. provide B. collect C. repeat D. listen
2. A. energy B. pollution C. solution D. appearance

**II. Choose the best answer:**
1. I wish I ___ a movie star.
A. am B. was C. were D. will be
2. The children are playing ___ in the garden.
A. happy B. happily C. happiness D. unhappy
3. He was tired, ___ he went to bed early.
A. so B. because C. but D. although

**III. Guided Cloze Test:**
"Television is one of the most important (1)___ of communication. It (2)___ pictures and sounds from around the world..."
1. A. ways B. means C. kinds D. types
2. A. gives B. sends C. brings D. takes

**IV. Sentence Transformation:**
1. I don't have a new car.
-> I wish ________________________________.
2. "Do you like pop music?" she asked me.
-> She asked me ________________________________.`
      },
      {
        id: 'ed5',
        name: 'Đề thi chính thức 2025 - Tiếng Anh (Hà Nội)',
        type: 'PDF',
        content: `### SỞ GIÁO DỤC VÀ ĐÀO TẠO HÀ NỘI - ĐỀ THI CHÍNH THỨC 2025
**Môn thi: TIẾNG ANH**

---

**I. PHONETICS (1.0 pt)**
1. A. h**o**use B. h**o**ur C. h**o**me D. h**o**t
2. A. finish**ed** B. stopp**ed** C. work**ed** D. mov**ed**

**II. GRAMMAR & VOCABULARY (4.0 pts)**
1. The man ___ lives next door is a doctor.
A. who B. whom C. which D. whose
2. If it ___ tomorrow, we will go camping.
A. rain B. rains C. will rain D. rained
3. She is very good ___ English.
A. at B. in C. on D. for
4. We have lived here ___ 2010.
A. for B. since C. in D. during

**III. READING (2.5 pts)**
"London is the capital city of England and the United Kingdom. It is a very old city with a long history..."
1. What is the capital of the UK?
2. Is London an old city?

**IV. WRITING (2.5 pts)**
1. They built this school in 1995.
-> This school ________________________________.
2. "Where are you going?" he asked me.
-> He asked me ________________________________.
3. I can't swim.
-> I wish ________________________________.`
      },
      {
        id: 'ed6',
        name: 'Chuyên đề: Phrasal Verbs thường gặp trong đề thi',
        type: 'PDF',
        content: `### TỔNG HỢP PHRASAL VERBS THƯỜNG GẶP (ÔN THI VÀO 10)

1. **Look after:** Chăm sóc (= take care of)
2. **Look for:** Tìm kiếm (= search for)
3. **Look up:** Tra cứu (từ điển)
4. **Go on:** Tiếp tục (= continue)
5. **Give up:** Từ bỏ (= stop)
6. **Take off:** Cất cánh / Cởi ra
7. **Put on:** Mặc vào
8. **Turn on/off:** Bật/Tắt
9. **Turn up/down:** Vặn to/nhỏ (âm lượng)
10. **Fill in:** Điền vào (mẫu đơn)

**Bài tập áp dụng:**
1. Please ___ the lights before leaving the room.
2. She is ___ her lost keys everywhere.
3. Don't ___! You can do it.`
      },
      {
        id: 'ed7',
        name: 'Chuyên đề: Câu điều kiện (Conditional Sentences)',
        type: 'PDF',
        content: `### CHUYÊN ĐỀ: CÂU ĐIỀU KIỆN (CONDITIONAL SENTENCES)

**1. Loại 0 (Zero Conditional):**
- Cấu trúc: If + S + V(s/es), S + V(s/es)
- Cách dùng: Diễn tả sự thật hiển nhiên, chân lý.

**2. Loại 1 (First Conditional):**
- Cấu trúc: If + S + V(s/es), S + will + V-inf
- Cách dùng: Diễn tả sự việc có thể xảy ra ở hiện tại hoặc tương lai.

**3. Loại 2 (Second Conditional):**
- Cấu trúc: If + S + V2/ed (be=were), S + would + V-inf
- Cách dùng: Diễn tả sự việc không có thật ở hiện tại.

**4. Loại 3 (Third Conditional):**
- Cấu trúc: If + S + had + V3/ed, S + would + have + V3/ed
- Cách dùng: Diễn tả sự việc không có thật trong quá khứ.`
      },
      {
        id: 'ed8',
        name: 'Đề thi thử 2026 - Lần 1 (Hệ thống AIS)',
        type: 'PDF',
        content: `### ĐỀ THI THỬ VÀO 10 NĂM 2026 - LẦN 1 (AIS SYSTEM)
**Môn thi: TIẾNG ANH**

---

**I. PHONETICS (1.0 pt)**
*Choose the word whose underlined part is pronounced differently:*
1. A. h<u>o</u>me B. g<u>o</u> C. d<u>o</u> D. n<u>o</u>
2. A. watch<u>ed</u> B. look<u>ed</u> C. stopp<u>ed</u> D. want<u>ed</u>

**II. GRAMMAR & VOCABULARY (4.0 pts)**
*Choose the best option:*
1. If I _______ you, I would buy that car.
A. am B. was C. were D. had been
2. She has been learning English _______ 5 years.
A. for B. since C. in D. during

**III. READING (3.0 pts)**
*Read the passage and answer the questions...*

**IV. WRITING (2.0 pts)**
*Rewrite the sentences:*
1. "I am a student," he said.
-> He said that ____________________.
2. They built this house in 2010.
-> This house ____________________.`
      }
    ]
  },
  literature: {
    theory: [
      { 
        id: 'l1', 
        title: 'Nghị luận xã hội & Nghị luận văn học', 
        content: `### CHUYÊN ĐỀ: PHƯƠNG PHÁP LÀM VĂN NGHỊ LUẬN

---

#### 1. Nghị luận xã hội (2,0 điểm)
**a. Nghị luận về một tư tưởng, đạo lý:**
- **Giải thích:** Giải thích các từ ngữ trọng tâm, các vế câu, nghĩa đen, nghĩa bóng của vấn đề.
- **Bàn luận:** 
  - Tại sao vấn đề đó đúng/sai? 
  - Tác dụng/tác hại của vấn đề đối với cá nhân và cộng đồng.
  - Dẫn chứng: Lấy từ thực tế đời sống, lịch sử (cần cụ thể, tiêu biểu).
- **Mở rộng, phê phán:** Nhìn nhận vấn đề ở nhiều góc độ khác nhau, phê phán những biểu hiện lệch lạc.
- **Bài học nhận thức và hành động:** Rút ra thông điệp cho bản thân.

**b. Nghị luận về một hiện tượng đời sống:**
- **Nêu thực trạng:** Hiện tượng đang diễn ra như thế nào? (Có số liệu, ví dụ minh họa).
- **Nguyên nhân:** Khách quan (xã hội, giáo dục...) và Chủ quan (ý thức cá nhân).
- **Hậu quả/Tác dụng:** Ảnh hưởng tích cực hoặc tiêu cực.
- **Giải pháp:** Cần làm gì để phát huy hoặc ngăn chặn?

#### 2. Nghị luận văn học (5,0 điểm)
**a. Phân tích nhân vật:**
- Giới thiệu tác giả, tác phẩm, nhân vật.
- Phân tích các đặc điểm của nhân vật qua: hoàn cảnh, ngoại hình, hành động, ngôn ngữ, nội tâm.
- Đánh giá nghệ thuật xây dựng nhân vật.

**b. Phân tích đoạn thơ/bài thơ:**
- Cảm nhận về nội dung (hình ảnh, cảm xúc).
- Phân tích nghệ thuật (thể thơ, biện pháp tu từ, nhịp điệu).` 
      },
      { 
        id: 'l2', 
        title: 'Hệ thống tác phẩm trọng tâm', 
        content: `### TỔNG HỢP KIẾN THỨC TÁC PHẨM VĂN HỌC LỚP 9

---

#### 1. Chuyện người con gái Nam Xương (Nguyễn Dữ)
- **Nhân vật Vũ Nương:** Đại diện cho vẻ đẹp và bi kịch của người phụ nữ trong xã hội phong kiến.
- **Giá trị nhân đạo:** Ca ngợi vẻ đẹp, cảm thông với số phận, phê phán xã hội bất công.
- **Chi tiết cái bóng:** Là nút thắt cũng là nút mở của câu chuyện, mang giá trị nghệ thuật đặc sắc.

#### 2. Làng (Kim Lân)
- **Nhân vật ông Hai:** Tình yêu làng hòa quyện với tình yêu nước, tinh thần kháng chiến.
- **Tình huống truyện:** Tin làng Chợ Dầu theo giặc - thử thách lòng yêu nước của ông Hai.
- **Nghệ thuật:** Miêu tả tâm lý nhân vật tinh tế qua ngôn ngữ đối thoại và độc thoại nội tâm.

#### 3. Lặng lẽ Sa Pa (Nguyễn Thành Long)
- **Nhân vật anh thanh niên:** Vẻ đẹp của con người lao động mới: yêu nghề, trách nhiệm, khiêm tốn, hiếu khách.
- **Chất thơ:** Vẻ đẹp của thiên nhiên Sa Pa và vẻ đẹp của tâm hồn con người.

#### 4. Chiếc lược ngà (Nguyễn Quang Sáng)
- **Tình cha con:** Tình cảm sâu nặng, thiêng liêng của ông Sáu và bé Thu trong hoàn cảnh chiến tranh.
- **Chi tiết chiếc lược:** Biểu tượng của tình cha con bất diệt.` 
      },
    ],
    questions: [
      {
        id: 'lq1_e',
        subject: 'literature',
        topic: 'Tác phẩm',
        difficulty: 'easy',
        content: 'Tác giả của bài thơ "Đồng chí" là ai?',
        options: ['Chính Hữu', 'Phạm Tiến Duật', 'Huy Cận', 'Xuân Quỳnh'],
        answer: 'Chính Hữu',
        explanation: 'Chính Hữu là tác giả của bài thơ "Đồng chí" nổi tiếng về tình đồng đội.'
      },
      {
        id: 'lq1',
        subject: 'literature',
        topic: 'Tác phẩm',
        difficulty: 'medium',
        content: 'Nhân vật chính trong tác phẩm "Lặng lẽ Sa Pa" là ai?',
        options: ['Ông họa sĩ', 'Cô kỹ sư', 'Anh thanh niên', 'Bác lái xe'],
        answer: 'Anh thanh niên',
        explanation: 'Anh thanh niên 27 tuổi làm công tác khí tượng kiêm vật lý địa cầu trên đỉnh Yên Sơn là nhân vật trung tâm.'
      },
      {
        id: 'lq3',
        subject: 'literature',
        topic: 'Tác phẩm',
        difficulty: 'hard',
        content: 'Chi tiết "cái bóng" trong "Chuyện người con gái Nam Xương" có vai trò gì?',
        options: ['Thắt nút câu chuyện', 'Mở nút câu chuyện', 'Cả thắt nút và mở nút', 'Chỉ là chi tiết trang trí'],
        answer: 'Cả thắt nút và mở nút',
        explanation: 'Cái bóng khiến bé Đản hiểu lầm, dẫn đến bi kịch của Vũ Nương (thắt nút). Sau đó, cũng chính cái bóng giúp Trương Sinh hiểu ra nỗi oan của vợ (mở nút).'
      },
      {
        id: 'lq2',
        subject: 'literature',
        topic: 'Nghị luận',
        difficulty: 'easy',
        content: 'Bố cục của một bài văn nghị luận thường gồm mấy phần?',
        options: ['2 phần', '3 phần', '4 phần', '5 phần'],
        answer: '3 phần',
        explanation: 'Bố cục chuẩn gồm: Mở bài, Thân bài và Kết bài.'
      },
      {
        id: 'lq4',
        subject: 'literature',
        topic: 'Nghị luận',
        difficulty: 'hard',
        content: 'Yêu cầu quan trọng nhất khi viết đoạn văn nghị luận xã hội về một tư tưởng đạo lý là gì?',
        options: ['Phải có dẫn chứng thực tế', 'Phải giải thích được tư tưởng đó', 'Phải rút ra bài học cho bản thân', 'Tất cả các ý trên'],
        answer: 'Tất cả các ý trên',
        explanation: 'Một bài nghị luận xã hội hoàn chỉnh cần giải thích, chứng minh bằng dẫn chứng và rút ra bài học nhận thức, hành động.'
      },
      {
        id: 'lq5',
        subject: 'literature',
        topic: 'Tác phẩm',
        difficulty: 'medium',
        content: 'Trong "Chiếc lược ngà", tại sao bé Thu không nhận cha lúc đầu?',
        options: ['Vì ông Sáu quá già', 'Vì vết sẹo trên mặt ông Sáu', 'Vì bà ngoại bảo thế', 'Vì bé Thu ghét ông Sáu'],
        answer: 'Vì vết sẹo trên mặt ông Sáu',
        explanation: 'Bé Thu không nhận ra cha vì ông Sáu có vết sẹo dài trên mặt, khác với tấm hình chụp chung với má mà em thường xem.'
      },
      {
        id: 'lq6',
        subject: 'literature',
        topic: 'Tác phẩm',
        difficulty: 'hard',
        content: 'Nghệ thuật đặc sắc nhất của truyện ngắn "Làng" là gì?',
        options: ['Xây dựng tình huống truyện bất ngờ', 'Miêu tả tâm lý nhân vật tinh tế', 'Ngôn ngữ mang đậm chất nông thôn', 'Tất cả các ý trên'],
        answer: 'Tất cả các ý trên',
        explanation: 'Kim Lân đã thành công trong việc xây dựng tình huống tin làng theo giặc để bộc lộ tình yêu làng, yêu nước của ông Hai qua tâm lý và ngôn ngữ đặc sắc.'
      },
      {
        id: 'lq7_h',
        subject: 'literature',
        topic: 'Lý luận văn học',
        difficulty: 'hard',
        content: 'Ý kiến nào sau đây nói đúng nhất về chức năng của văn học?',
        options: [
          'Văn học chỉ để giải trí sau giờ làm việc căng thẳng.',
          'Văn học giúp con người hiểu biết, giáo dục tư tưởng và bồi đắp tâm hồn.',
          'Văn học là công cụ để ghi chép lịch sử một cách chính xác nhất.',
          'Văn học chỉ dành cho những người có tâm hồn mơ mộng.'
        ],
        answer: 'Văn học giúp con người hiểu biết, giáo dục tư tưởng và bồi đắp tâm hồn.',
        explanation: 'Văn học có ba chức năng chính: nhận thức, giáo dục và thẩm mỹ. Nó giúp con người hoàn thiện bản thân và hướng tới cái Đẹp.'
      }
    ],
    documents: [
      { 
        id: 'ld1', 
        name: 'Đề thi chính thức 2025 - Ngữ văn (Đà Nẵng)', 
        type: 'PDF', 
        content: `### SỞ GIÁO DỤC VÀ ĐÀO TẠO ĐÀ NẴNG - ĐỀ THI CHÍNH THỨC 2025
**Môn thi: NGỮ VĂN**
*Thời gian: 120 phút*

---

**Phần I. Đọc hiểu (3,0 điểm)**
Cho đoạn trích: "Sống là để cống hiến, để yêu thương..."
1. Xác định phương thức biểu đạt chính của đoạn trích.
2. Theo tác giả, thế nào là sống có ý nghĩa?
3. Em hiểu như thế nào về câu văn: "Mỗi người là một bông hoa trong vườn hoa nhân loại"?

**Phần II. Làm văn (7,0 điểm)**
Câu 1 (2,0 điểm): Từ nội dung phần Đọc hiểu, hãy viết một đoạn văn (khoảng 200 chữ) trình bày suy nghĩ của em về ý nghĩa của sự thấu hiểu trong cuộc sống.

Câu 2 (5,0 điểm): Phân tích vẻ đẹp tâm hồn và phong cách sống của nhân vật anh thanh niên trong truyện ngắn "Lặng lẽ Sa Pa" của Nguyễn Thành Long. Từ đó, em có suy nghĩ gì về lý tưởng sống của thế hệ trẻ ngày nay?` 
      },
      { 
        id: 'ld2', 
        name: 'Sổ tay văn học 2026 - Kiến thức trọng tâm', 
        type: 'PDF', 
        content: `### SỔ TAY VĂN HỌC ÔN THI VÀO 10 (2026)
**Tổng hợp kiến thức trọng tâm**

1. **Văn học trung đại:**
   *   Chuyện người con gái Nam Xương (Nguyễn Dữ).
   *   Truyện Kiều (Nguyễn Du) - Các đoạn trích: Chị em Thúy Kiều, Kiều ở lầu Ngưng Bích.
2. **Thơ hiện đại:**
   *   Đồng chí (Chính Hữu).
   *   Bài thơ về tiểu đội xe không kính (Phạm Tiến Duật).
   *   Đoàn thuyền đánh cá (Huy Cận).
   *   Bếp lửa (Bằng Việt).
3. **Truyện hiện đại:**
   *   Làng (Kim Lân).
   *   Lặng lẽ Sa Pa (Nguyễn Thành Long).
   *   Chiếc lược ngà (Nguyễn Quang Sáng).

*(Sổ tay bao gồm phân tích chi tiết từng tác phẩm, các luận điểm chính và dẫn chứng tiêu biểu...)*` 
      },
      { 
        id: 'ld3', 
        name: '10 bài văn mẫu nghị luận xã hội đạt điểm cao', 
        type: 'PDF', 
        content: `### 10 BÀI VĂN MẪU NGHỊ LUẬN XÃ HỘI TIÊU BIỂU (2026)

**Đề 1: Suy nghĩ về lòng trắc ẩn.**
*Dàn ý:*
- Giải thích: Lòng trắc ẩn là sự thấu cảm, thương xót trước nỗi đau của người khác.
- Phân tích: Giúp con người xích lại gần nhau, xoa dịu nỗi đau, đẩy lùi cái ác.
- Dẫn chứng: Các hoạt động từ thiện, giúp đỡ người hoạn nạn.
- Phản đề: Phê phán lối sống vô cảm, ích kỷ.
- Bài học: Rèn luyện trái tim biết yêu thương.

**Đề 2: Ý chí và nghị lực trong cuộc sống.**
*Dàn ý:*
- Giải thích: Ý chí là bản lĩnh, sự kiên trì vượt qua khó khăn.
- Phân tích: Là chìa khóa của thành công, giúp con người trưởng thành hơn.
- Dẫn chứng: Thầy giáo Nguyễn Ngọc Ký, Nick Vujicic...

*(Tài liệu bao gồm 8 bài văn mẫu khác về các chủ đề: Ước mơ, Sự tử tế, Bảo vệ môi trường...)*` 
      },
      {
        id: 'ld4',
        name: 'Tuyển tập đề thi thử Ngữ văn 2026 - Toàn quốc',
        type: 'PDF',
        content: `### TUYỂN TẬP ĐỀ THI THỬ NGỮ VĂN 2026 - TOÀN QUỐC

**Đề số 1 (Hà Nội):**
*Phần I:* Đọc hiểu đoạn trích trong "Cánh đồng bất tận" của Nguyễn Ngọc Tư.
*Phần II:* 
1. Nghị luận về sự cần thiết của việc đọc sách.
2. Phân tích tình yêu làng của nhân vật ông Hai trong truyện ngắn "Làng".

**Đề số 2 (TP.HCM):**
*Phần I:* Đọc hiểu bài thơ "Mẹ" của Đỗ Trung Quân.
*Phần II:*
1. Nghị luận về lòng hiếu thảo.
2. Cảm nhận về đoạn trích "Kiều ở lầu Ngưng Bích".`
      },
      {
        id: 'ld5',
        name: 'Đề thi thử 2026 - Lần 3 (Hệ thống AIS)',
        type: 'PDF',
        content: `### HỆ THỐNG GIÁO DỤC AIS - ĐỀ THI THỬ VÀO 10 LẦN 3 (2026)
**Môn thi: NGỮ VĂN**

---

**Phần I: Đọc hiểu (3,0 điểm)**
Đọc đoạn trích sau và trả lời câu hỏi:
"Học vấn không chỉ là chuyện đọc sách, nhưng đọc sách vẫn là một con đường quan trọng của học vấn..." (Bàn về đọc sách - Chu Quang Tiềm)
1. Phương thức biểu đạt chính của đoạn trích là gì?
2. Theo tác giả, tại sao phải đọc sách?
3. Việc đọc sách có ý nghĩa như thế nào đối với em?

**Phần II: Làm văn (7,0 điểm)**
Câu 1 (2,0 điểm): Viết đoạn văn nghị luận (khoảng 200 chữ) về ý nghĩa của sự tự tin.
Câu 2 (5,0 điểm): Phân tích tình cảm cha con sâu nặng trong đoạn trích truyện ngắn "Chiếc lược ngà" của Nguyễn Quang Sáng.`
      },
      {
        id: 'ld6',
        name: 'Chuyên đề: Phân tích các đoạn trích Truyện Kiều',
        type: 'PDF',
        content: `### CHUYÊN ĐỀ: TRUYỆN KIỀU (NGUYỄN DU)

---

**1. Đoạn trích: Chị em Thúy Kiều**
- Vẻ đẹp của Thúy Vân: "Khuôn trăng đầy đặn, nét ngài nở nang...", vẻ đẹp phúc hậu, hài hòa với thiên nhiên.
- Vẻ đẹp của Thúy Kiều: "Làn thu thủy, nét xuân sơn...", vẻ đẹp sắc sảo, mặn mà, dự báo một số phận truân chuyên.
- Nghệ thuật: Bút pháp ước lệ tượng trưng, lấy vẻ đẹp thiên nhiên làm chuẩn mực.

**2. Đoạn trích: Kiều ở lầu Ngưng Bích**
- Cảnh ngộ cô đơn, buồn tủi của Kiều.
- Nỗi nhớ người yêu (Kim Trọng) và nỗi nhớ cha mẹ.
- Nghệ thuật tả cảnh ngụ tình: Tám câu thơ cuối với điệp ngữ "Buồn trông" tạo nhịp điệu dồn dập, diễn tả nỗi buồn ngày càng tăng tiến.`
      },
      {
        id: 'ld7',
        name: 'Chuyên đề: Phân tích bài thơ "Đồng chí" (Chính Hữu)',
        type: 'PDF',
        content: `### CHUYÊN ĐỀ: BÀI THƠ "ĐỒNG CHÍ" (CHÍNH HỮU)

**1. Cơ sở hình thành tình đồng chí:**
- Cùng cảnh ngộ nghèo khó: "Quê hương anh nước mặn đồng chua / Làng tôi nghèo đất cày lên sỏi đá".
- Cùng chung lý tưởng, nhiệm vụ: "Súng bên súng, đầu sát bên đầu".
- Cùng chia sẻ gian lao, thiếu thốn: "Đêm rét chung chăn thành đôi tri kỷ".

**2. Biểu hiện của tình đồng chí:**
- Sự thấu hiểu, sẻ chia: "Ruộng nương anh gửi bạn thân cày / Gian nhà không mặc kệ gió lung lay".
- Sự đồng cảm, gắn bó: "Thương nhau tay nắm lấy bàn tay".

**3. Biểu tượng cao đẹp của tình đồng chí:**
- Hình ảnh "Đầu súng trăng treo": Sự kết hợp giữa hiện thực và lãng mạn, giữa chiến sĩ và thi sĩ.`
      },
      {
        id: 'ld8',
        name: 'Đề thi thử 2026 - Lần 4 (Hệ thống AIS)',
        type: 'PDF',
        content: `### HỆ THỐNG GIÁO DỤC AIS - ĐỀ THI THỬ VÀO 10 LẦN 4 (2026)
**Môn thi: NGỮ VĂN**

---

**Phần I: Đọc hiểu (3,0 điểm)**
Đọc đoạn trích sau và trả lời câu hỏi:
"Sống là để cống hiến, để yêu thương..."
1. Xác định phương thức biểu đạt chính của đoạn trích.
2. Theo tác giả, thế nào là sống có ý nghĩa?
3. Em hiểu như thế nào về câu văn: "Mỗi người là một bông hoa trong vườn hoa nhân loại"?

**Phần II: Làm văn (7,0 điểm)**
Câu 1 (2,0 điểm): Viết đoạn văn nghị luận (khoảng 200 chữ) về ý nghĩa của lòng hiếu thảo.
Câu 2 (5,0 điểm): Phân tích vẻ đẹp tâm hồn và phong cách sống của nhân vật anh thanh niên trong truyện ngắn "Lặng lẽ Sa Pa" của Nguyễn Thành Long.`
      }
    ]
  }
};
